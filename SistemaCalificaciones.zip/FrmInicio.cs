﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using $safeprojectname$.Datos;

namespace $safeprojectname$
{
    public partial class FrmInicio : Form
    {
        public FrmInicio()
        {
            InitializeComponent();
        }

        private void dgvInicio_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void button2_Click(object sender, EventArgs e)
        {
            FrmCategorias frm = new FrmCategorias();
            frm.Show();
            this.Hide();
        }

        private void btnprod_Click(object sender, EventArgs e)
        {
            FrmProductos frm = new FrmProductos();
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmClientes frm = new FrmClientes();
            frm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmProveedores frm = new FrmProveedores();
            frm.Show();
            this.Hide();
        }

        private void FrmInicio_Load(object sender, EventArgs e)
        {
            CargarResumen();

        }

        private void CargarResumen()
        {
            using (var db = new SistemaVentasContext())
            {
                // Productos con categoría y proveedor
                var productos = db.Productos
                    .Select(p => new
                    {
                        p.Nombre,
                        p.Precio,
                        p.Stock,
                        Categoria = p.Categoria.Nombre,
                        Proveedor = p.Proveedor.Nombre
                    })
                    .ToList();

                dgvInicio.DataSource = productos;

                // Opcional: ocultar columnas si quieres
                // dgvInicio.Columns["IdProducto"].Visible = false;
            }
        }
    }
}
