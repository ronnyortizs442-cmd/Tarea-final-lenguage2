﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using $safeprojectname$.Datos;
using $safeprojectname$.Modelo;


namespace $safeprojectname$
{
    public partial class FrmCategorias : Form
    {
        int idCategoriaSeleccionada = 0;
        public FrmCategorias()
        {
            InitializeComponent();
        }

        private void lblLogo_Click(object sender, EventArgs e)
        {
            FrmInicio frm = new FrmInicio();
            frm.Show();
            this.Hide();
        }

        private void btnprod_Click(object sender, EventArgs e)
        {
            FrmProductos frm = new FrmProductos();
            frm.Show();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            FrmClientes frm = new FrmClientes();
            frm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmProveedores frm = new FrmProveedores();
            frm.Show();
            this.Hide();
        }

        private void FrmCategorias_Load(object sender, EventArgs e)
        {
            CargarCategorias();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

            using (var db = new SistemaVentasContext())
            {
                db.Categorias.Add(new Categoria
                {
                    Nombre = txtNombre.Text,
                    Descripcion = txtDescripcion.Text,
                });
                db.SaveChanges();
            }

            CargarCategorias();
            Limpiar();
        }

        private void CargarCategorias()
        {
            using (var db = new SistemaVentasContext())
            {
                dgvCategorias.DataSource = db.Categorias.ToList();
                dgvCategorias.Columns["IdCategoria"].Visible = false;
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            using (var db = new SistemaVentasContext())
            {
                var Categoria = db.Categorias.Find(idCategoriaSeleccionada);

                if (Categoria != null)
                {
                    Categoria.Nombre = txtNombre.Text;
                    Categoria.Descripcion = txtDescripcion.Text;

                    db.SaveChanges();
                }
            }

            CargarCategorias();
            Limpiar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idCategoriaSeleccionada == 0)
            {
                MessageBox.Show("Seleccione una categoria.");
                return;
            }

            using (var db = new SistemaVentasContext())
            {
                var Categoria = db.Categorias.Find(idCategoriaSeleccionada);

                if (Categoria != null)
                {
                    db.Categorias.Remove(Categoria);
                    db.SaveChanges();
                }
                CargarCategorias();
                Limpiar();
            }

        }

        private void dgvCategorias_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var fila = dgvCategorias.Rows[e.RowIndex];
                idCategoriaSeleccionada = Convert.ToInt32(fila.Cells["IdCategoria"].Value);

                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtDescripcion.Text = fila.Cells["Descripcion"].Value.ToString();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();


        }

        void Limpiar()
        {
            txtNombre.Clear();
            txtDescripcion.Clear();          
            idCategoriaSeleccionada = 0;
        }
    }
}