﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modelo
{
    class Periodo
    {
        [Key]
        int IdPeriodo { get; set; }
        string Nombre { get; set; }
        string FechaInicio { get; set; }
        string FechaFin { get; set; }

        public List<Inscripcion> Inscripciones { get; set; }

    }
}
