﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modelo
{
    class Inscripcion
    {
        public int IdInscripcion { get; set; }

        public int EstudianteId { get; set; }
        public Estudiante Estudiante { get; set; }

        public int MateriaId { get; set; }
        public Materia Materia { get; set; }

        public int ProfesorId { get; set; }
        public Profesor Profesor { get; set; }

        public int PeriodoId { get; set; }
        public Periodo Periodo { get; set; }

        public List<Calificacion> Calificaciones { get; set; }

    }
}
