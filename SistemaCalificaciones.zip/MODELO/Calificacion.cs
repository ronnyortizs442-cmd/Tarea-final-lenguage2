﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modelo
{
    class Calificacion
    {
        [Key]
        int id_calificacion { get; set;} 
        int InscripcionId { get; set; }
        decimal Calificacion1 { get; set; }
        decimal Calificacion2 { get; }
        decimal Calificacion3 { get;set; }
        decimal Calificacion4 { get; set; }
        decimal Examen { get; set; }

        public List<Calificacion> Inscripciones { get; set; }
    }
}
