﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace $safeprojectname$.Modelo
{
    class Profesor
    {
        [Key]
        int IdProfesor { get; set; }
        string Nombre { get; set; }
        string Apellido { get; set; }
        string Especialidad { get; set; }

        public List<Inscripcion> Inscripciones { get; set; }

    }
}
