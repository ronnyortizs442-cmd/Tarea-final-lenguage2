﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modelo
{
    class Materia
    {
        [Key]
        int IdMateria { get; set; }
        string Creditos { get; set; }

        public List<Inscripcion> Inscripciones { get; set; }
    }
}
