﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Modelo
{
    class Estudiante
    {
        [Key]
        int IdEstudiante { get; set; }
        string Nombre { get; set; }
        string Apellido { get; set; }
        string Cedula { get; set; }
        string FechaNacimiento { get; set; }
        bool Activo { get; set; }

        public List<Inscripcion> Inscripcionses { get; set; }
    }
}
