﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using $safeprojectname$.Datos;
using $safeprojectname$.Modelo;

namespace $safeprojectname$
{
    public partial class FrmProveedores : Form
    {
        int idProveedorSeleccionado = 0;

        public FrmProveedores()
        {
            InitializeComponent();
        }

        private void lblLogo_Click(object sender, EventArgs e)
        {
            FrmInicio frm = new FrmInicio();
            frm.Show();
            this.Hide();
        }

        private void btnprod_Click(object sender, EventArgs e)
        {
            FrmProductos frm = new FrmProductos();
            frm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmCategorias frm = new FrmCategorias();
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmClientes frm = new FrmClientes();
            frm.Show();
            this.Hide();
        }

        private void FrmProveedores_Load(object sender, EventArgs e)
        {
            CargarProveedores();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string email = txtEmail.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(direccion) ||
                string.IsNullOrEmpty(telefono) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                if (addr.Address != email) throw new Exception();
            }
            catch
            {
                MessageBox.Show("Ingrese un email válido.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(telefono, @"^(809|829|849)\d{7}$"))
            {
                MessageBox.Show("Ingrese un teléfono válido de República Dominicana.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var db = new SistemaVentasContext())
            {
                if (db.Proveedores.Any(p => p.Email == email || p.Telefono == telefono))
                {
                    MessageBox.Show("Ya existe un proveedor con este email o teléfono.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                db.Proveedores.Add(new Proveedor
                {
                    Nombre = nombre,
                    Direccion = direccion,
                    Telefono = telefono,
                    Email = email
                });
                db.SaveChanges();
            }

            CargarProveedores();
            Limpiar();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (idProveedorSeleccionado == 0) return;

            using (var db = new SistemaVentasContext())
            {
                var prov = db.Proveedores.Find(idProveedorSeleccionado);
                if (prov != null)
                {
                    prov.Nombre = txtNombre.Text.Trim();
                    prov.Direccion = txtDireccion.Text.Trim();
                    prov.Telefono = txtTelefono.Text.Trim();
                    prov.Email = txtEmail.Text.Trim();

                    db.SaveChanges();
                }
            }

            CargarProveedores();
            Limpiar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idProveedorSeleccionado == 0) return;

            using (var db = new SistemaVentasContext())
            {
                var prov = db.Proveedores.Find(idProveedorSeleccionado);
                if (prov != null)
                {
                    db.Proveedores.Remove(prov);
                    db.SaveChanges();
                }
            }

            CargarProveedores();
            Limpiar();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void CargarProveedores()
        {
            using (var db = new SistemaVentasContext())
            {
                dgvProveedores.DataSource = db.Proveedores
                    .Select(p => new
                    {
                        p.IdProveedor,
                        p.Nombre,
                        p.Telefono,
                        p.Direccion,
                        p.Email
                    }).ToList();

                if (dgvProveedores.Columns.Contains("IdProveedor"))
                    dgvProveedores.Columns["IdProveedor"].Visible = false;
            }
        }

        private void dgvProveedores_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var fila = dgvProveedores.Rows[e.RowIndex];
            idProveedorSeleccionado = Convert.ToInt32(fila.Cells["IdProveedor"].Value);

            txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
            txtDireccion.Text = fila.Cells["Direccion"].Value.ToString();
            txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
            txtEmail.Text = fila.Cells["Email"].Value.ToString();
        }

        private void Limpiar()
        {
            txtNombre.Clear();
            txtDireccion.Clear();
            txtTelefono.Clear();
            txtEmail.Clear();
            idProveedorSeleccionado = 0;
        }
    }
}
