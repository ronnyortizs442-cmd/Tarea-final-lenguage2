﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using $safeprojectname$.Datos;
using $safeprojectname$.Modelo;

namespace $safeprojectname$
{
    public partial class FrmProductos : Form
    {
        int idProductoSeleccionado = 0;
        public FrmProductos()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            FrmInicio frm = new FrmInicio();
            frm.Show();
            this.Hide();
        }

        private void btnprod_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmCategorias frm = new FrmCategorias();
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmClientes frm = new FrmClientes();
            frm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmProveedores frm = new FrmProveedores();
            frm.Show();
            this.Hide();
        }

        private void FrmProductos_Load(object sender, EventArgs e)
        {
            CargarProductos();
            CargarComboCategorias();
            CargarComboProveedores();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                !decimal.TryParse(txtPrecio.Text, out decimal precio) ||
                !int.TryParse(txtStock.Text, out int stock))
            {
                MessageBox.Show("Revise Nombre, Precio o Stock.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var db = new SistemaVentasContext())
            {
                db.Productos.Add(new Producto
                {
                    Nombre = txtNombre.Text.Trim(),
                    Precio = precio,
                    Stock = stock,
                    IdCategoria = (int)cmbCategoria.SelectedValue,
                    IdProveedor = (int)cmbProveedor.SelectedValue
                });
                db.SaveChanges();
            }

            CargarProductos();
            Limpiar();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (idProductoSeleccionado == 0) return;

            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                !decimal.TryParse(txtPrecio.Text, out decimal precio) ||
                !int.TryParse(txtStock.Text, out int stock))
            {
                MessageBox.Show("Revise Nombre, Precio o Stock.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var db = new SistemaVentasContext())
            {
                var prod = db.Productos.Find(idProductoSeleccionado);
                if (prod != null)
                {
                    prod.Nombre = txtNombre.Text.Trim();
                    prod.Precio = precio;
                    prod.Stock = stock;
                    prod.IdCategoria = (int)cmbCategoria.SelectedValue;
                    prod.IdProveedor = (int)cmbProveedor.SelectedValue;

                    db.SaveChanges();
                    MessageBox.Show("Producto actualizado");
                }
            }
            CargarProductos();
            Limpiar();
            
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idProductoSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un producto.", "Aviso");
                return;
            }

            DialogResult r = MessageBox.Show("¿Seguro que desea eliminar este producto?",
                                             "Confirmar",
                                             MessageBoxButtons.YesNo,
                                             MessageBoxIcon.Question);

            if (r == DialogResult.Yes)
            {
                using (var db = new SistemaVentasContext())
                {
                    var prod = db.Productos.Find(idProductoSeleccionado);
                    if (prod != null)
                    {
                        db.Productos.Remove(prod);
                        db.SaveChanges();
                    }
                }

                CargarProductos();
                Limpiar();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            if (idProductoSeleccionado == 0) return;

            using (var db = new SistemaVentasContext())
            {
                var prod = db.Productos.Find(idProductoSeleccionado);
                if (prod != null)
                {
                    db.Productos.Remove(prod);
                    db.SaveChanges();
                }
            }

            CargarProductos();
            Limpiar();
        }

        private void CargarProductos()
        {
            using (var db = new SistemaVentasContext())
            {
                dgvProductos.DataSource = db.Productos
                    .Select(p => new
                    {
                        p.IdProducto,
                        p.Nombre,
                        p.Precio,
                        p.Stock,
                        Categoria = p.Categoria.Nombre,
                        Proveedor = p.Proveedor.Nombre
                    }).ToList();

                if (dgvProductos.Columns.Contains("IdProducto"))
                    dgvProductos.Columns["IdProducto"].Visible = false;
            }
        }

        private void CargarComboCategorias()
        {
            using (var db = new SistemaVentasContext())
            {
                cmbCategoria.DataSource = db.Categorias.ToList();
                cmbCategoria.DisplayMember = "Nombre";
                cmbCategoria.ValueMember = "IdCategoria";
            }
        }

        private void CargarComboProveedores()
        {
            using (var db = new SistemaVentasContext())
            {
                cmbProveedor.DataSource = db.Proveedores.ToList();
                cmbProveedor.DisplayMember = "Nombre";
                cmbProveedor.ValueMember = "IdProveedor";
            }
        }

        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var fila = dgvProductos.Rows[e.RowIndex];
            idProductoSeleccionado = Convert.ToInt32(fila.Cells["IdProducto"].Value);
            txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
            txtPrecio.Text = fila.Cells["Precio"].Value.ToString();
            txtStock.Text = fila.Cells["Stock"].Value.ToString();
            cmbCategoria.Text = fila.Cells["Categoria"].Value.ToString();
            cmbProveedor.Text = fila.Cells["Proveedor"].Value.ToString();
        }

        
        private void Limpiar()
        {
            txtNombre.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            cmbCategoria.SelectedIndex = 0;
            cmbProveedor.SelectedIndex = 0;
            idProductoSeleccionado = 0;
        }
    }
}
