﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Forms;
using $safeprojectname$.Datos;
using $safeprojectname$.Modelo;

namespace $safeprojectname$
{
    public partial class FrmClientes : Form
    {
        private Cliente Cliente = new Cliente();

        int idClienteSeleccionado = 0;

        public FrmClientes()
        {
            InitializeComponent();
        }

        private void CargarClientes()
        {
            using (var db = new SistemaVentasContext())
            {
                dgvClientes.DataSource = db.Clientes.ToList();
                dgvClientes.Columns["IdCliente"].Visible = false;
            }
        }

        private void lblLogo_Click(object sender, EventArgs e)
        {
            FrmInicio frm = new FrmInicio();
            frm.Show();
            this.Hide();
        }

        private void btnprod_Click(object sender, EventArgs e)
        {
            FrmProductos frm = new FrmProductos();
            frm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmCategorias frm = new FrmCategorias();
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmProveedores frm = new FrmProveedores();
            frm.Show();
            this.Hide();
        }
        
        private void FrmClientes_Load(object sender, EventArgs e)
        {
            CargarClientes();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

            var cliente = new Cliente
            {
                Nombre = txtNombre.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtTelefono.Text,
                Email = txtEmail.Text
            };

            var resultados = new List<ValidationResult>();
            var contexto = new ValidationContext(cliente);

            if (!Validator.TryValidateObject(cliente, contexto, resultados, true))
            {
                MessageBox.Show(string.Join("\n", resultados.Select(x => x.ErrorMessage)));
                return;
            }

            // Si pasa la validación, guarda
            using (var db = new SistemaVentasContext())
            {
                db.Clientes.Add(cliente);
                db.SaveChanges();
            }

            CargarClientes();
            Limpiar();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            

            using (var db = new SistemaVentasContext())
            {
                var cliente = db.Clientes.Find(idClienteSeleccionado);

                if (cliente != null)
                {
                    cliente.Nombre = txtNombre.Text;
                    cliente.Direccion = txtDireccion.Text;
                    cliente.Telefono = txtTelefono.Text;
                    cliente.Email = txtEmail.Text;

                    db.SaveChanges();
                }
            }

            CargarClientes();
            Limpiar();
        }
           
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idClienteSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un cliente.");
                return;
            }

            using (var db = new SistemaVentasContext())
            {
                var cliente = db.Clientes.Find(idClienteSeleccionado);

                if (cliente != null)
                {
                    db.Clientes.Remove(cliente);
                    db.SaveChanges();
                }
            }

            CargarClientes();
            Limpiar();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar(); 
        }

        private void dgvClientes_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var fila = dgvClientes.Rows[e.RowIndex];

                idClienteSeleccionado = Convert.ToInt32(fila.Cells["IdCliente"].Value);

                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtDireccion.Text = fila.Cells["Direccion"].Value.ToString();
                txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
                txtEmail.Text = fila.Cells["Email"].Value.ToString();
            }
        }

        void Limpiar()
        {
            txtNombre.Clear();
            txtDireccion.Clear();
            txtTelefono.Clear();
            txtEmail.Clear();
            idClienteSeleccionado = 0;
        }
    }
}
