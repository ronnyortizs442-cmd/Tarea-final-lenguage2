﻿


namespace $safeprojectname$.Datos
{   
  
    class EstudianteDatos
    {
        public void Agregar() {

            


        



        }
    }
}
