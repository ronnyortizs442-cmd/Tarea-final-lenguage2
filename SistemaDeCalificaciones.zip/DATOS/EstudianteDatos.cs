﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Modelo;

namespace $safeprojectname$.Datos
{
    public class EstudianteDatos
    {
        private AppDbContext _context = new AppDbContext();

        // Obtener todos los estudiantes
        public List<Estudiante> ObtenerTodos()
        {
            return _context.Estudiantes.ToList();
        }

        // Guardar un nuevo estudiante
        public void Guardar(Estudiante estudiante)
        {
            _context.Estudiantes.Add(estudiante);
            _context.SaveChanges();
        }

        // Actualizar un estudiante existente
        public void Actualizar(Estudiante estudiante)
        {
            var existente = _context.Estudiantes.Find(estudiante.IdEstudiante);
            if (existente != null)
            {
                existente.Nombre = estudiante.Nombre;
                existente.Matricula = estudiante.Matricula;
                existente.Telefono = estudiante.Telefono;
                existente.Cedula = estudiante.Cedula;
                existente.Sexo = estudiante.Sexo;
                existente.FechaNacimiento = estudiante.FechaNacimiento;
                existente.Direccion = estudiante.Direccion;
                existente.Nacionalidad = estudiante.Nacionalidad;
                existente.Activo = estudiante.Activo;
                
                _context.SaveChanges();
            }
        }

        // Eliminar un estudiante por Id
        public void Eliminar(int id)
        {
            var estudiante = _context.Estudiantes.Find(id);
            if (estudiante != null)
            {
                _context.Estudiantes.Remove(estudiante);
                _context.SaveChanges();
            }
        }

        // Buscar estudiante por Id
        public Estudiante ObtenerPorId(int id)
        {
            return _context.Estudiantes.Find(id);
        }
    }
}
