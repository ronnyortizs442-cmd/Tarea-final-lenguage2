﻿using System;

namespace $safeprojectname$.Formularios.cs
{
    internal class estudianteDatos
    {
        public string Matricula { get; set; }
        public string Nombre { get; set; }
        public object Sexo { get; set; }
        public string Cedula { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Telefono { get; set; }
        public string Direccion { get; set; }
        public string Nacionalidad { get; set; }
        public bool Activo { get; set; }
    }
}