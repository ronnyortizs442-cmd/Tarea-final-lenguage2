﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using $safeprojectname$.Datos;
using $safeprojectname$.Modelo;

namespace $safeprojectname$.Formularios.cs
{
    public partial class FrmEstuduiante : Form
    {
        private EstudianteDatos estudianteDatos = new EstudianteDatos();



        public FrmEstuduiante()
        {
            InitializeComponent();
            CargarDatos();
        }


        private void CargarDatos()
        {
            dgvEstudiantes.DataSource = null;
            dgvEstudiantes.DataSource = estudianteDatos.ObtenerTodos();
        }

        private void Limpiar()
        {
            txtIdEstudiante.Clear();
            txtNombre.Clear();
            txtMatricula.Clear();
            txtTelefono.Clear();
            txtCedula.Clear();
            cmbSexo.SelectedIndex = -1;
            dtpFechaNacimiento.Value = DateTime.Today;
            txtDireccion.Clear();
            txtNacionalidad.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void FrmEstuduiante_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            var estudiante = new Estudiante
            {
                Nombre = txtNombre.Text,
                Matricula = txtMatricula.Text,
                Telefono = txtTelefono.Text,
                Cedula = txtCedula.Text,
                Sexo = cmbSexo.Text,
                FechaNacimiento = dtpFechaNacimiento.Value,
                Direccion = txtDireccion.Text,
                Nacionalidad = txtNacionalidad.Text,              
            };

            estudianteDatos.Guardar(estudiante);
            CargarDatos();
            Limpiar();
            MessageBox.Show("Estudiante guardado correctamente.");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (txtIdEstudiante.Text == "")
            {
                MessageBox.Show("Seleccione un estudiante para eliminar.");
                return;
            }

            int id = int.Parse(txtIdEstudiante.Text);
            estudianteDatos.Eliminar(id); // Aquí usamos la clase de datos
            CargarDatos();
            Limpiar();
            MessageBox.Show("Estudiante eliminado correctamente.");
        }

        private void dgvEstudiante_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Obtener la fila seleccionada
                var row = dgvEstudiantes.Rows[e.RowIndex];

                // Guardar el Id en txtId (aunque sea auto-incremental)
                txtIdEstudiante.Text = row.Cells["IdEstudiante"].Value?.ToString();

                txtMatricula.Text = row.Cells["Matricula"].Value?.ToString();
                txtNombre.Text = row.Cells["Nombre"].Value?.ToString();
                txtTelefono.Text = row.Cells["Telefono"].Value?.ToString();
                txtCedula.Text = row.Cells["Cedula"].Value?.ToString();
                cmbSexo.Text = row.Cells["Sexo"].Value?.ToString();

                // Fecha de nacimiento en DateTimePicker
                var fecha = row.Cells["FechaNacimiento"].Value;
                if (fecha != null)
                    dtpFechaNacimiento.Value = Convert.ToDateTime(fecha);

                txtDireccion.Text = row.Cells["Direccion"].Value?.ToString();
                txtNacionalidad.Text = row.Cells["Nacionalidad"].Value?.ToString();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (txtIdEstudiante.Text == "")
            {
                MessageBox.Show("Seleccione un estudiante para actualizar.");
                return;
            }

            var estudiante = new Estudiante
            {
                IdEstudiante = int.Parse(txtIdEstudiante.Text),
                Matricula = txtMatricula.Text,
                Nombre = txtNombre.Text,
                Telefono = txtTelefono.Text,
                Cedula = txtCedula.Text,
                Sexo = cmbSexo.Text,
                FechaNacimiento = dtpFechaNacimiento.Value,
                Direccion = txtDireccion.Text,
                Nacionalidad = txtNacionalidad.Text
            };

            estudianteDatos.Actualizar(estudiante);
            CargarDatos();
            Limpiar();
            MessageBox.Show("Estudiante actualizado correctamente.");
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void txtIdEstudiante_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
