﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modelo
{
    [Table("Inscripcion")]
    public class Inscripcion
    {
        [Key]
        public int IdInscripcion { get; set; }

        public int EstudianteId { get; set; }
        public int MateriaId { get; set; }
        public int ProfesorId { get; set; }
        public int PeriodoId { get; set; }
    }
}
