﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modelo
{
    [Table("Calificacion")]
    public class Calificacion
    {
        [Key]
        public int IdCalificacion { get; set; }

        public int InscripcionId { get; set; }

        public decimal? Calificacion1 { get; set; }
        public decimal? Calificacion2 { get; set; }
        public decimal? Calificacion3 { get; set; }
        public decimal? Calificacion4 { get; set; }
        public decimal? Examen { get; set; }
    }
}
