﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Modelo
{
    [Table("Materia")]
    public class Materia
    {
        [Key]
        public int IdMateria { get; set; }

        public string Nombre { get; set; }
        public int Creditos { get; set; }
    }
}
